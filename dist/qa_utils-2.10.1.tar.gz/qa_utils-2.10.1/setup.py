from setuptools import setup, find_packages

setup(
    name='qa_utils',
    version='2.10.1',
    packages=find_packages(), # Or packages=['your_package_name'] if you have just one package
)